import typing
import os
import matplotlib.pyplot as plt
import numpy as np

def lecture_fichier(chemin: str) -> typing.Optional[str]:
    """
    Lecture d'un fichier.

    :param chemin: le chemin du fichier
    :return: la chaine de caractère contenant tout le fichier ou None si le fichier n'a pu être lu
    """

    try:
        with open(chemin, encoding="utf8") as fh:
            return fh.read()
    except:
        print("Le fichier n'existe pas %s", os.path.abspath(chemin))
        return None
    

fichier = lecture_fichier("fichiert.txt")
fichier = fichier.split("\n")

lignes = []

for i in range(0, len(fichier), 1):
    if(fichier[i].find("0x0") == -1):
        lignes.append(fichier[i])
        
#print(lignes)

dates1 = []
dates2 = []
dates3 = []
ipsources = []
ipdests = []
flags = []
seqs = []
acks = []
wins = []
lengths = []

ipsourcesmeme = []
ipdestsmeme = []
ipsourcesmemenomb = []
ipdestsmemenomb = []

nombadressesource = 0

filecsv = open("fichiercsv.csv", "a")
filecsv.write("Hour;Minute;Second;IP Source;IP Destination;Length;Flags\n")

for ii in range(0, len(lignes), 1):
    # pour commencer je vais essayer dans le premier trame

    try:
        fichier = lignes[ii]
        tmpfichier = fichier
    
        fichier = fichier.split(":")

        dates1.append(fichier[0])
        dates2.append(fichier[1])
        dates3.append(fichier[2].split(".")[0])

        fichier = fichier[2]

        fichier = fichier.split("IP ")[1]
        fichier = fichier.split(" >")
        
        ipsources.append(fichier[0])
            
        nombadressesource = nombadressesource + 1
        
        ipdests.append(fichier[1])
        
        try:
            flags.append((tmpfichier.split(": Flags ", 1)[1]).split(",", 1)[0])
        except Exception:
            flags.append("Non")
            pass
    
        fichier = tmpfichier.split(",")
        #print(fichier)
        
        try:
            if(fichier[len(fichier)-1].split("length")[1].find(':') != -1):
                lengths.append((fichier[len(fichier)-1].split("length")[1]).split(":", 1)[0])
            else:
                lengths.append(fichier[len(fichier)-1].split("length")[1])
        except Exception : 
            lengths.append("Non")
            pass

        filecsv.write(dates1[ii] + ";" + dates2[ii] + ";" + dates3[ii] + ";" + ipsources[ii] + ";" + ipdests[ii] + ";" + lengths[ii] + ";" + flags[ii] + "\n")

        print(dates1[ii] + " " + dates2[ii] + " " + dates3[ii] + " " + ipsources[ii] + " " + ipdests[ii] + " " + lengths[ii] + " " + flags[ii])
    
    except Exception:
        pass
    
filecsv.close()
# fin de calcul et extrait de donnee
try:
    for ib in range(0, len(ipsources), 1):
        
        if(ipsources[ib].rsplit('.', 1)[1].isnumeric() == True):
            ipsources[ib] = ipsources[ib].rsplit('.', 1)[0]

        if(ipdests[ib].rsplit('.', 1)[1].isnumeric() == True):
            ipdests[ib] = ipdests[ib].rsplit('.', 1)[0]

except Exception:
    pass

ajouteri = 1

for ia in range(0, len(ipsources), 1):
    ajouteri = 1
    for iia in range(0, len(ipsourcesmeme), 1):
        if(ipsourcesmeme[iia] == ipsources[ia]):
            ipsourcesmemenomb[iia] = str(int(ipsourcesmemenomb[iia])+1)
            ajouteri = 0
    if(ajouteri == 1):
        ipsourcesmeme.append(ipsources[ia])
        ipsourcesmemenomb.append("1")

ajouteri = 1

for ih in range(0, len(ipdests), 1):
    ajouteri = 1
    for iih in range(0, len(ipdestsmeme), 1):
        if(ipdestsmeme[iih] == ipdests[ih]):
            ipdestsmemenomb[iih] = str(int(ipdestsmemenomb[iih])+1)
            ajouteri = 0
    if(ajouteri == 1):
        ipdestsmeme.append(ipdests[ih])
        ipdestsmemenomb.append("1")

flagsmeme = []
flagsmemenomb = []

ajouterii = 1

for ie in range(0, len(flags), 1):
    ajouterii = 1
    for iie in range(0, len(flagsmeme), 1):
        if(flagsmeme[iie] == flags[ie]):
            flagsmemenomb[iie] = str(int(flagsmemenomb[iie])+1)
            ajouterii = 0
    if(ajouterii == 1):
        flagsmeme.append(flags[ie])
        flagsmemenomb.append("1")

name = flagsmeme
data = flagsmemenomb

explode=(0, 0, 0, 0, 0, 0)
plt.pie(data, explode=explode, labels=name, autopct='%1.1f%%', startangle=90, shadow=True)
plt.axis('equal')
plt.savefig("flagsgraph.png")
plt.show()

name = ipsourcesmeme
data = ipsourcesmemenomb

explode=[]
for iz in range(0, len(ipsourcesmeme), 1):
    explode.append(0)
plt.pie(data, explode=explode, labels=name, autopct='%1.1f%%', startangle=90, shadow=True)
plt.axis('equal')
plt.savefig("ipsourcegraph.png")
plt.show()

#fin graphiques

#commence page web et autres informations

length0nomb = 0
lengthnonnomb = 0
lengthplus = 0
lengthdiff = []

existe = 0

for ic in range(0, len(lengths), 1):
    existe = 0
    for idd in range(0, len(lengthdiff), 1):
        if(lengthdiff[idd] == lengths[ic]):
            existe = 1
    
    if(existe == 0):
        lengthdiff.append(lengths[ic])
        
    if(lengths[ic] == "Non"):
        lengthnonnomb = lengthnonnomb + 1
    elif(int(lengths[ic]) == 0):
        length0nomb = length0nomb + 1
    elif(int(lengths[ic]) > lengthplus):
        lengthplus = int(lengths[ic])

flagsnonnomb = 0
flagsplusid = 0
flagsplus = 0

for ig in range(0, len(flags), 1):

    if(flags[ig] == "Non"):
        flagsnonnomb = flagsnonnomb + 1

for igg in range(0, len(flagsmeme), 1):

    if(int(flagsmemenomb[igg]) > int(flagsplus)):
        flagsplus = flagsmemenomb[igg]
        flagsplusid = igg


fichierhtml = open("filehtml.html", "a")
fichierhtml.write('''
<html>
<head>
    <title>SAE15</title>
</head>
<body>
    <h1>Les résultats important</h1>
    <h4>Nombre de trame : ''' + str(nombadressesource) + '''</h4>
    <h4>Nombre d'adresse source différent : ''' + str(len(ipsourcesmemenomb)) + '''</h4>
    <h4>Nombre d'adresse destination différent : ''' + str(len(ipdestsmemenomb)) + '''</h4>
    <h4>Nomdre de length différent : ''' + str(len(lengthdiff)) + '''</h4>
    <h4>Nombre de trames qui ont 0 comme length : ''' + str(length0nomb) + '''</h4>
    <h4>Nombre de trames qui ont pas de length : ''' + str(lengthnonnomb) + '''</h4>
    <h4>La plus grand valeur de length détécté : ''' + str(lengthplus) + '''</h4>
    <h4>Nombre de flags différent : ''' + str(len(flagsmeme)) + '''</h4>
    <h4>Nombre de trames aui ont pas de flags : ''' + str(flagsnonnomb) + '''</h4>
    <h4>Le type de flags plus utilisé : ''' + flagsmeme[flagsplusid] + ''' Nombre d'utiliastion : ''' + str(flagsplus) +'''</h4>
    <h3>Graphiques de Flags</h3>
    <img src="flagsgraph.png" alt="graphiques-de-flags">
    
</body>
</html>
''')
fichierhtml.close()

#fin page web